import React from "react";

const Footer = () => {
    return (
        <footer className="footer-container">
            <div className="footer-content">
                <div className="footer-section about">
                    <h2>About Us</h2>
                    <p>
                        Welcome to our restaurant! We offer a variety of delicious dishes made from the freshest ingredients.
                        Join us for an unforgettable dining experience.
                    </p>
                </div>

                <div className="footer-section contact">
                    <h2>Contact Us</h2>
                    <p>Email: info@restaurant.com</p>
                    <p>Phone: +123 456 7890</p>
                    <p>Address: 123 Main Street, Anytown, USA</p>
                </div>

                <div className="footer-section social">
                    <h2>Follow Us</h2>
                    <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
                    <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a>
                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
                </div>
            </div>

            <div className="footer-bottom">
                <p>&copy; {new Date().getFullYear()} Restaurant. All rights reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;
